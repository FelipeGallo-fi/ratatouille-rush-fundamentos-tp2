#include "restaurant.h"

#include <time.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#define MILANESA_NAPOLITANA 'M'
#define HAMBURGUESA 'H'
#define PARRILLA 'P'
#define RATATOUILLE 'R'
#define MILANESA_NAPOLITANA_ID 1
#define HAMBURGUESA_ID 2
#define PARRILLA_ID 3
#define RATATOUILLE_ID 4
#define TIEMPO_MILANESA_NAPOLITANA 30
#define TIEMPO_HAMBURGUESA 15
#define TIEMPO_PARRILLA 20
#define TIEMPO_RATATOUILLE 25
#define MIN_COMENSALES 1
#define MESA  'T'
#define LINGUINI 'L'
#define COCINA 'C'
#define MONEDA 'M'
#define PATINES 'P'
#define MOPA 'O'
#define CHARCO 'H'
#define ARRIBA 'W'
#define ABAJO 'S'
#define IZQUIERDA 'A'
#define DERECHA 'D'
#define TOMAR_PEDIDO 'T'
#define VACIO '.'
#define ASIENTO_OCUPADO 'X'
#define CUCARACHA 'U'

const int CANTIDAD_MESAS = 10;
const int CANTIDAD_HERRAMIENTAS = 14;
const int CANTIDAD_OBSTACULOS = 5;
const int INDICE_MOPA = 0;
const int VALOR_MONEDA = 1000;
const int RANGO_PACIENCIA_MINIMA = 100;
const int RANGO_PACIENCIA_MAXIMA = 101;
const int GANO = 1;
const int PERDIO = -1;
const int CONTINUAR_JUGANDO = 0;
const int OBJETIVO_DINERO = 150000;
const int MAX_MOVIMIENTOS = 200;
const int CANTIDAD_MONEDAS = 8;
const int CANTIDAD_MOPAS = 1;
const int CANTIDAD_PATINES = 5;
const int CANTIDAD_CHARCOS = 5;
const int DISTANCIA_CUCARACHA = 2;
const int PRECIO_MESA_CUATRO = 20000;
const int PRECIO_MESA_UNO = 5000;
const int ERROR = -1;

/*Structs utilizados*/

typedef struct mesa_aleat{
    coordenada_t coordenada;
    int cantidad_lugares;
}mesa_aleat_t;


/*Mis funciones*/

/*
* Pre: - 
* Posts: Inicializa todos los valores como false.
*/

int distancia_manhattan(coordenada_t primera_posicion, coordenada_t segunda_posicion){
    return abs(primera_posicion.fil - segunda_posicion.fil) + abs(primera_posicion.col - segunda_posicion.col);
}

/*
* Pre: - 
* Posts: 
*/

int buscar_indice_mopa(objeto_t herramientas[], int cantidad_herramientas){
    for(int i = 0; i < cantidad_herramientas; i++){
        if(herramientas[i].tipo == MOPA){
            return i;
        }
    }
    return ERROR;
}

/*
Pre condiciones:

Post condiciones: 

*/

bool estoy_en_misma_pos(coordenada_t posicion_1, coordenada_t posicion_2){
    return posicion_1.fil == posicion_2.fil && posicion_1.col == posicion_2.col;
}

/*
Pre: maximo_valor debe ser si o si mayor o igual a minimo_valor
Post: devuelve un numero aleatorio en el rango especificado.
*/

int generar_numero_aleatorio(int rango_maximo, int rango_minimo){
    return ((rand() % rango_maximo) + rango_minimo); 
}


/*
* Pre: - 
* Posts: Inicializa todos los valores como false.
*/

void inicializar_tablero(bool tablero[MAX_FILAS][MAX_COLUMNAS]) {
    for (int i = 0; i < MAX_FILAS; i++) {
        for (int j = 0; j < MAX_COLUMNAS; j++) {
            tablero[i][j] = false;
        }
    }
}

/*
* Pre condiciones: Mapa debe estar previamente creado.

* Post condiciones: Inicializa todos los valores del mapa como VACIO.

*/

void inicializar_mapa(char mapa[MAX_FILAS][MAX_COLUMNAS]){
    for (int i = 0; i < MAX_FILAS; i++) {
        for (int j = 0; j < MAX_COLUMNAS; j++) {
            mapa[i][j] = VACIO; 
        }
    }
}


/*
* Pre condiciones: Juego.cantidad_mesas/cantidad_herramientas/cantidad_obstaculos deben estar previamente inicializados. 

* Post condiciones: Asigna las posiciones de los elementos de juego en la matriz mapa recibida por parametro.

*/

void asignar_posiciones(juego_t *juego,char mapa[MAX_FILAS][MAX_COLUMNAS]){

    for(int i = 0; i < juego->cantidad_mesas; i++){
        for(int j = 0; j < juego->mesas[i].cantidad_lugares; j++){
            mapa[juego->mesas[i].posicion[j].fil][juego->mesas[i].posicion[j].col] = MESA;
            if(juego->mesas[i].cantidad_comensales != 0){
                for(int k = 0; k < juego->mesas[i].cantidad_comensales; k++){
                    mapa[juego->mesas[i].posicion[k].fil][juego->mesas[i].posicion[k].col] = ASIENTO_OCUPADO;
                }
            }
        }
    }

    for(int i = 0; i < juego->cantidad_herramientas; i++){
        mapa[juego->herramientas[i].posicion.fil][juego->herramientas[i].posicion.col] = juego->herramientas[i].tipo;
    }

    for(int i = 0; i < juego->cantidad_obstaculos ; i++){
        mapa[juego->obstaculos[i].posicion.fil][juego->obstaculos[i].posicion.col] = juego->obstaculos[i].tipo;
    }

    mapa[juego->mozo.posicion.fil][juego->mozo.posicion.col] = LINGUINI;

    mapa[juego->cocina.posicion.fil][juego->cocina.posicion.col] = COCINA;
}

/*
* Pre condiciones: El mapa y todos los campos en juego a mostrar deben estar incializados.

* Post condiciones: Muestra el mapa y los datos importantes del juego por pantalla.

*/

void imprimir_juego(juego_t juego){

    char mapa[MAX_FILAS][MAX_COLUMNAS];
    inicializar_mapa(mapa);

    asignar_posiciones(&juego, mapa);
    system("clear");
    for (int i = 0; i < MAX_FILAS; i++){
        for (int j = 0; j < MAX_COLUMNAS; j++){
            printf("| %c ", mapa[i][j]);
        }
        printf("\n");
    }


    printf("\nDinero = %i, Movimientos (A los 200 se termina el dia) = %i, Pedidos tomados = %i, Pedidos en bandeja = %i, Patines disponibles = %i, Patines activados = %s , Mopa agarrada: %s\n", juego.dinero, juego.movimientos, juego.mozo.cantidad_pedidos, juego.mozo.cantidad_bandeja,juego.mozo.cantidad_patines, juego.mozo.patines_puestos ? "Sí" : "No", juego.mozo.tiene_mopa ? "Sí" : "No");
}

/*
* Pre condiciones: Los valores de la mesa y el mapa deben estar previamente inicializados. 

* Post condiciones: Devuelve true si la posicion de la mesa es valida, false en caso contrario.

*/

bool es_mesa_valida(mesa_aleat_t valores_mesa, bool tablero[MAX_FILAS][MAX_COLUMNAS]){

    bool es_valida = true;

    int fila_aleatoria = valores_mesa.coordenada.fil;
    int columna_aleatoria = valores_mesa.coordenada.col;
    int cantidad_lugares = valores_mesa.cantidad_lugares;

    if (fila_aleatoria < 0 || columna_aleatoria < 0 || fila_aleatoria + cantidad_lugares > MAX_FILAS || columna_aleatoria + cantidad_lugares > MAX_COLUMNAS) {
        es_valida = false;
    }


    for (int i = fila_aleatoria - 1; i <= fila_aleatoria + cantidad_lugares; i++) {
        for (int j = columna_aleatoria - 1; j <= columna_aleatoria + cantidad_lugares; j++) {
            if (i >= 0 && i < MAX_FILAS && j >= 0 && j < MAX_COLUMNAS) {
                if (tablero[i][j]) {
                    es_valida = false;
                }
            }
        }
    }


    if(es_valida){
        for(int i = fila_aleatoria; i < fila_aleatoria + cantidad_lugares; i++){
            for(int j = columna_aleatoria; j < columna_aleatoria + cantidad_lugares; j++){
                tablero[i][j] = true;
            }
        }
    }

    return es_valida;
}

/*
* Pre: La posicion y el tablero deben estar inicializados.
* Post: Devuelve true si la posicion es valida, false en caso contrario.
*/

bool es_posicion_valida(coordenada_t posicion_aleatoria, bool tablero[MAX_FILAS][MAX_COLUMNAS]){
    int i = posicion_aleatoria.fil;
    int j = posicion_aleatoria.col;

    if(!tablero[i][j] && i < MAX_FILAS && j < MAX_COLUMNAS){
        tablero[i][j] = true;
        return true;
    }
    return false;
}

/*
* Pre condiciones: i debe estar previamente inicializado.

* Post condiciones:Crea la posicion inicial para una mesa.  Si i es menor a 4 asigna una mesa de 4 comensales, si i es mayor o igual a 4 asigna una mesa de 1 comensal. 

*/

mesa_aleat_t generar_mesa(int i){
    mesa_aleat_t valores_mesa_aleatoria ;
    valores_mesa_aleatoria.coordenada.fil = rand() % MAX_FILAS;
    valores_mesa_aleatoria.coordenada.col = rand() % MAX_COLUMNAS;
    if (i < 4) {
        valores_mesa_aleatoria.cantidad_lugares = 4;
    } else {
        valores_mesa_aleatoria.cantidad_lugares = 1; 
    }

    return valores_mesa_aleatoria;
}

/*
* Pre: valores_mesa debe estar inicializado.
* Post: Inicializa el struct mesa.
*/

void asignar_mesa(mesa_t *mesa, mesa_aleat_t valores_mesa) {
    if(valores_mesa.cantidad_lugares == 1){
        mesa->posicion[0].fil = valores_mesa.coordenada.fil;
        mesa->posicion[0].col = valores_mesa.coordenada.col;

        mesa->cantidad_lugares = valores_mesa.cantidad_lugares;
    }else{
        mesa->posicion[0].fil = valores_mesa.coordenada.fil;
        mesa->posicion[0].col = valores_mesa.coordenada.col;
        mesa->posicion[1].fil = valores_mesa.coordenada.fil;
        mesa->posicion[1].col = valores_mesa.coordenada.col + 1;
        mesa->posicion[2].fil = valores_mesa.coordenada.fil + 1;
        mesa->posicion[2].col = valores_mesa.coordenada.col;
        mesa->posicion[3].fil = valores_mesa.coordenada.fil + 1;
        mesa->posicion[3].col = valores_mesa.coordenada.col + 1;
    
        mesa->cantidad_lugares= valores_mesa.cantidad_lugares;
    }
    mesa->cantidad_comensales = 0;
    mesa->pedido_tomado = false;
    mesa->paciencia = 0;
}


/*
* Pre condiciones: MAX_FILAS y MAX_COLUMNAS deben estar previamente incializados.

* Post condiciones: Crea una valor aleatorio en el rango de MAX_FILAS y MAX_COLUMNAS, creando una fila y columna aleatoria. 

*/

coordenada_t generar_posicion_aleatoria(){
    coordenada_t posicion_aleatoria ;
    posicion_aleatoria.fil = rand() % MAX_FILAS;
    posicion_aleatoria.col = rand() % MAX_COLUMNAS;
    return posicion_aleatoria;
}

/*
* Pre condiciones: Tablero y la cantidad de mesas deben estar previamente inicializados.

* Post condiciones: Inicializa las mesas.

*/

void inicializar_mesas(bool tablero[MAX_FILAS][MAX_COLUMNAS], juego_t *juego){

    
    int i = 0;
    while (i <= juego->cantidad_mesas){


        mesa_aleat_t valores_mesa_aleatoria = generar_mesa(i);


        bool mesa_chequeada = es_mesa_valida(valores_mesa_aleatoria, tablero);

        
        if(mesa_chequeada){
            asignar_mesa(&juego->mesas[i], valores_mesa_aleatoria);
            i++;
        }

        
    }
}

/*
* Pre condiciones: Tablero debe estar previamente inicializado.

* Post condiciones: Inicializa la cocina.

*/

void inicializar_cocina(bool tablero[MAX_FILAS][MAX_COLUMNAS], cocina_t *cocina){
    
    coordenada_t posicion_aleatoria_cocina;

    bool es_pos_valida_cocina;

    bool posicion_invalida = true;

    while(posicion_invalida){
        posicion_aleatoria_cocina = generar_posicion_aleatoria();
        es_pos_valida_cocina = es_posicion_valida(posicion_aleatoria_cocina, tablero);
        if(es_pos_valida_cocina){
            cocina->posicion.fil = posicion_aleatoria_cocina.fil;
            cocina->posicion.col = posicion_aleatoria_cocina.col;
            posicion_invalida = false;
        }
    }

    cocina->cantidad_preparacion = 0;
    cocina->cantidad_listos = 0;
    cocina->platos_preparacion = NULL;
    cocina->platos_listos = NULL;
}

/*
* Pre condiciones: Tablero debe estar previamente inicializado.

* Post condiciones: Inicializa un objeto.

*/

void inicializar_objetos(bool tablero[MAX_FILAS][MAX_COLUMNAS], char tipo, objeto_t *objeto){
        bool es_pos_valida_objetos;
        bool posicion_invalida = true;
        while(posicion_invalida){
            coordenada_t posicion = generar_posicion_aleatoria();
            es_pos_valida_objetos = es_posicion_valida(posicion, tablero);
            if(es_pos_valida_objetos){
                objeto->posicion.fil = posicion.fil;
                objeto->posicion.col = posicion.col;
                objeto->tipo = tipo;
                posicion_invalida = false;
            }
        }
    }

/*
* Pre condiciones: El tablero, la cantidad de herramientas y cantidad de patines deben estar inicializados.

* Post condiciones: Inicializa los elementos de herramientas.
*/

void inicializar_herramientas(bool tablero[MAX_FILAS][MAX_COLUMNAS], juego_t *juego){
    for(int i = 0; i < juego->cantidad_herramientas ; i++){
        if( i == 0){
            inicializar_objetos(tablero, MOPA, &juego->herramientas[i]);
        }else if(i <= CANTIDAD_PATINES){
            inicializar_objetos(tablero, PATINES, &juego->herramientas[i]);
        }else{
            inicializar_objetos(tablero, MONEDA, &juego->herramientas[i]);
        }
    }
}

/*
* Pre condiciones: Tablero y cantidad de obstaculos deben estar previamente inicializados.

* Post condiciones: Inicializa los obstaculos.

*/

void inicializar_obstaculos(bool tablero[MAX_FILAS][MAX_COLUMNAS], juego_t *juego){
    for(int i = 0; i < juego->cantidad_obstaculos ; i++){
        inicializar_objetos(tablero, CHARCO, &juego->obstaculos[i]);
    }
}

/*
* Pre condiciones: Tablero debe estar previamente inicializado.

* Post condiciones: Inicializa el mozo.

*/

void inicializar_mozo(bool tablero[MAX_FILAS][MAX_COLUMNAS], mozo_t *mozo){
    
    coordenada_t posicion_aleatoria_mozo;

    bool es_pos_valida_mozo;

    bool posicion_invalida = true;
    while(posicion_invalida){
        posicion_aleatoria_mozo = generar_posicion_aleatoria();
        es_pos_valida_mozo = es_posicion_valida(posicion_aleatoria_mozo, tablero);
        if(es_pos_valida_mozo){
            mozo->posicion.fil = posicion_aleatoria_mozo.fil;
            mozo->posicion.col = posicion_aleatoria_mozo.col;
            posicion_invalida = false;
        }
    }
    mozo->tiene_mopa = false;
    mozo->patines_puestos = false;
    mozo->cantidad_patines = 0;
    mozo->cantidad_pedidos = 0;
    mozo->cantidad_bandeja = 0;
}



/*
* Pre condiciones: Mapa debe estar previamente inicializado, la accion debe ser valida y la posicion debe estar inicializada.

* Post condiciones: Devuelve la validez de la nueva posicion generada del mozo.

*/

bool es_accion_valida_mozo(coordenada_t posicion, juego_t juego){

    bool es_valida = true;

    if(posicion.fil >= MAX_FILAS || posicion.fil < 0 || posicion.col >= MAX_COLUMNAS || posicion.col < 0){
        es_valida = false;
    }

    for(int i = 0; i < juego.cantidad_mesas; i++){
        for(int j = 0; j < juego.mesas[i].cantidad_lugares; j++){
            if(posicion.fil == juego.mesas[i].posicion[j].fil && posicion.col == juego.mesas[i].posicion[j].col){
                es_valida = false;
            }
        }
    }

    return es_valida;
}

/*
* Pre condiciones: Las posiciones de las herramientas, los obstaculos y el mozo deben estar previamente inicializadas.

* Post condiciones: Devuelve si se puede soltar la mopa.

*/

bool puedo_soltar_mopa(coordenada_t posicion_mozo, juego_t *juego){

    bool es_accion_valida = true;

    for(int i = 0; i < juego->cantidad_herramientas; i++){
        if(juego->herramientas[i].posicion.fil == posicion_mozo.fil && juego->herramientas[i].posicion.col == posicion_mozo.col){
            es_accion_valida = false;
        }
    }

    for(int i = 0; i < juego->cantidad_obstaculos; i++){
        if(juego->obstaculos[i].posicion.fil == posicion_mozo.fil && juego->obstaculos[i].posicion.col == posicion_mozo.col){
            es_accion_valida = false;
        }
    }

    if(juego->cocina.posicion.fil == posicion_mozo.fil && juego->cocina.posicion.col == posicion_mozo.col){
        es_accion_valida = false;
    }

    return es_accion_valida;
}

/*
* Pre condiciones: 

* Post condiciones:

*/

void eliminar_mopa(juego_t *juego, int indice) {
    for (int i = indice; i < juego->cantidad_herramientas - 1; i++) {
        juego->herramientas[i] = juego->herramientas[i + 1];
    }
    juego->cantidad_herramientas--; 
}

/*
* Pre condiciones: 

* Post condiciones:

*/

void agregar_mopa(juego_t *juego, objeto_t mopa) {
    juego->herramientas[juego->cantidad_herramientas] = mopa;
    juego->cantidad_herramientas++;
}


/*
* Pre condiciones: La posicion del mozo debe estar inicializada.

* Post condiciones: Realiza la accion relacionada con la mopa.

*/

void interaccion_mopa(coordenada_t posicion_mozo, juego_t *juego){
    int indice_mopa = buscar_indice_mopa(juego->herramientas,juego->cantidad_herramientas);
    if(!juego->mozo.tiene_mopa){
        if(juego->herramientas[indice_mopa].posicion.fil == posicion_mozo.fil && juego->herramientas[indice_mopa].posicion.col == posicion_mozo.col){
            juego->mozo.tiene_mopa = true;
            eliminar_mopa(juego, indice_mopa);
            printf("\nMopa agarrada.\n");
        }else{
            printf("\nNo es posible agarrar la mopa.\n");
        }
    }else if(juego->mozo.tiene_mopa){
        bool mopa_soltada = puedo_soltar_mopa(posicion_mozo, juego);
        if(!mopa_soltada){
            printf("\nNo es posible soltar la mopa sobre un espacio ocupado.\n");
        }else{
            objeto_t mopa;
            mopa.posicion = posicion_mozo;
            mopa.tipo = MOPA;
            agregar_mopa(juego, mopa);
            juego->mozo.tiene_mopa = false;
            printf("\nMopa soltada.\n");
        }
    }
}

/*
Pre:
Post:
*/

bool hay_posicion_libre(juego_t juego, coordenada_t posicion){
    bool hay_lugar = true;

    for(int i = 0; i < juego.cantidad_mesas; i++){
        for(int j = 0; j < juego.mesas[i].cantidad_lugares; j++){
            if(posicion.fil == juego.mesas[i].posicion[j].fil && posicion.col == juego.mesas[i].posicion[j].col){
                hay_lugar = false;
            }
        }
    }

    for(int i = 0; i < juego.cantidad_herramientas ; i++){
        if(posicion.fil == juego.herramientas[i].posicion.fil && posicion.col == juego.herramientas[i].posicion.col){
            hay_lugar = false;
        }
    }

    for(int i = 0; i < juego.cantidad_obstaculos ; i++){
        if(posicion.fil == juego.obstaculos[i].posicion.fil && posicion.col == juego.obstaculos[i].posicion.col){
            hay_lugar = false;
        }
    }

    if(posicion.fil == juego.mozo.posicion.fil && posicion.col == juego.mozo.posicion.col){
        hay_lugar = false;
    }

    if(posicion.fil == juego.cocina.posicion.fil && posicion.col == juego.cocina.posicion.col){
        hay_lugar = false;
    }

    if(juego.mozo.tiene_mopa == false && juego.herramientas[0].posicion.fil == posicion.fil && juego.herramientas[0].posicion.col == posicion.col){
        hay_lugar = false;
    }

    return hay_lugar;
}

/*
Pre:
Post:
*/

int distancia_de_cucaracha(juego_t *juego, mesa_t mesa) {
    int distancia_minima = 100; 
    for(int j = 0; j < mesa.cantidad_lugares; j++) {
        for(int k = 0; k < juego->cantidad_obstaculos; k++) {
            if(juego->obstaculos[k].tipo == CUCARACHA) {
                int distancia_actual = distancia_manhattan(mesa.posicion[j], juego->obstaculos[k].posicion);
                if(distancia_actual < distancia_minima) {
                    distancia_minima = distancia_actual;
                }
            }
        }
    }
    return distancia_minima;
}

/*
Pre:
Post:
*/

void eliminar_pedido(pedido_t pedidos_o_bandeja[], int *cantidad_pedidos, int indice_mesa) {
    int i = 0;
    while (i < *cantidad_pedidos) {
        if (pedidos_o_bandeja[i].id_mesa == indice_mesa) {
            for (int j = i; j < *cantidad_pedidos - 1; j++) {
                pedidos_o_bandeja[j] = pedidos_o_bandeja[j + 1];
            }
            (*cantidad_pedidos)--;
        } else {
            i++;
        }
    }
}


/*
Pre:
Post:
*/

void actualizar_paciencia(int cantidad_mesas, mesa_t mesas[], juego_t *juego){
    for(int i = 0; i < cantidad_mesas; i++){

        if(mesas[i].cantidad_comensales != 0){

            mesas[i].paciencia--;

            int distancia_mesa_cucaracha = distancia_de_cucaracha(juego, mesas[i]);

            if(distancia_mesa_cucaracha <= DISTANCIA_CUCARACHA){
                mesas[i].paciencia -= DISTANCIA_CUCARACHA;
            }
    
        }
        
        if(mesas[i].paciencia <= 0){
            mesas[i].cantidad_comensales = 0;
        }
    }

}

/*
Pre:
Post:
*/

void interaccion_charcos(mozo_t mozo, objeto_t obstaculos[], int *cantidad_obstaculos){
    for(int i = 0; i < *cantidad_obstaculos ; i++){
        if(obstaculos[i].tipo == CHARCO && obstaculos[i].posicion.fil == mozo.posicion.fil && obstaculos[i].posicion.col == mozo.posicion.col){
            obstaculos[i] = obstaculos[*cantidad_obstaculos - 1];
            (*cantidad_obstaculos)--;
            i--;
        }
    }
}


/*
Pre:
Post:
*/

void interaccion_cucaracha(mozo_t mozo, objeto_t obstaculos[], int *cantidad_obstaculos){
    for(int i = 0; i < *cantidad_obstaculos; i++ ){
        bool hay_cucaracha = estoy_en_misma_pos(mozo.posicion, obstaculos[i].posicion);
        if(obstaculos[i].tipo == CUCARACHA && hay_cucaracha){
            obstaculos[i] = obstaculos[*cantidad_obstaculos - 1];
            (*cantidad_obstaculos)--;
            i--;
        }
    }
}
/*
Pre condiciones:

Post condiciones: 

*/

void entregar_pedidos(mozo_t *mozo, mesa_t mesas[], int cantidad_mesas, juego_t *juego) {
    for (int i = 0; i < cantidad_mesas; i++) {
        int distancia_de_mesa = distancia_manhattan(mozo->posicion, *mesas[i].posicion);

        if (distancia_de_mesa <= 1 && mesas[i].pedido_tomado) {
            int j = 0;
            bool pedido_entregado = false;

            while (j < mozo->cantidad_bandeja && !pedido_entregado) {
                if (mozo->bandeja[j].id_mesa == i) {
                    mesas[i].pedido_tomado = false;
                    eliminar_pedido(mozo->pedidos, &mozo->cantidad_bandeja, i);
                    mesas[i].cantidad_comensales = 0;
                    if (mesas[i].cantidad_lugares > 1) {
                        juego->dinero += PRECIO_MESA_CUATRO;
                    } else {
                        juego->dinero += PRECIO_MESA_UNO;
                    }
                    pedido_entregado = true;
                    printf("Pedido de la mesa %i entregado! \n", i);
                }
                j++; 
            }
        }
    }
}

/*
Pre condiciones:

Post condiciones: 

*/

void interaccion_monedas(mozo_t *mozo, objeto_t herramientas[], int *cantidad_herramientas, int *dinero){
    for(int i = 0; i < *cantidad_herramientas; i++ ){
        bool hay_moneda = estoy_en_misma_pos(mozo->posicion, herramientas[i].posicion);
        if(herramientas[i].tipo == MONEDA && hay_moneda){
            herramientas[i] = herramientas[*cantidad_herramientas - 1];
            (*cantidad_herramientas)--;
            (*dinero) += VALOR_MONEDA;
            printf("Moneda agarrada! \n");
            i--;
        }
    }
}

/*
Pre condiciones:

Post condiciones: 

*/

void interaccion_patines(mozo_t *mozo, objeto_t herramientas[], int *cantidad_herramientas){
    bool no_hay_patines = true;
    int i = 0;

    while(no_hay_patines && i < *cantidad_herramientas){
        bool hay_patines = estoy_en_misma_pos(mozo->posicion,herramientas[i].posicion);
        if(herramientas[i].tipo == PATINES && hay_patines){
            herramientas[i] = herramientas[*cantidad_herramientas - 1];
            i--;
            no_hay_patines = false;
            (*cantidad_herramientas)--;
            mozo->cantidad_patines++;
            printf("Patines agarrados \n");
            
        }
        i++;
    }
}

/*
Pre condiciones:

Post condiciones: 

*/

void pedidos_en_bandeja(mozo_t *mozo, cocina_t *cocina){

    int i = 0;
    int espacio_libre = mozo->cantidad_bandeja;

    while (i < cocina->cantidad_listos && espacio_libre < MAX_BANDEJA) {
        mozo->bandeja[espacio_libre] = cocina->platos_listos[i];
        mozo->cantidad_bandeja++;
        espacio_libre++;
        i++;
    }

    for (int j = i; j < cocina->cantidad_listos; j++) {
        cocina->platos_listos[j - i] = cocina->platos_listos[j];
    }
    cocina->cantidad_listos -= i;

    printf("Tienes %i pedidos listos en bandeja! \n", mozo->cantidad_bandeja);
}

/*
Pre condiciones:

Post condiciones: 

*/


void actualizar_pedidos(cocina_t *cocina) {
    for (int i = 0; i < cocina->cantidad_preparacion; i++) {

        cocina->platos_preparacion[i].tiempo_preparacion--;

        if (cocina->platos_preparacion[i].tiempo_preparacion <= 0) {

            if (cocina->cantidad_listos > 0) {
                cocina->platos_listos = realloc(cocina->platos_listos, (size_t)(cocina->cantidad_listos + 1) * sizeof(pedido_t));
            }else{
                cocina->platos_listos = malloc(sizeof(pedido_t));
            }

            if (cocina->platos_listos == NULL) {
                printf("Error al reservar la memoria para los platos listos.\n");
                return;
            }

            cocina->platos_listos[cocina->cantidad_listos] = cocina->platos_preparacion[i];

            cocina->cantidad_listos++;

            printf("El plato de la mesa %i está listo!\n", cocina->platos_listos[cocina->cantidad_listos - 1].id_mesa);

            

            for (int j = i; j < cocina->cantidad_preparacion - 1; j++) {
                cocina->platos_preparacion[j] = cocina->platos_preparacion[j + 1];
            }
            cocina->cantidad_preparacion--;

            if (cocina->cantidad_preparacion > 0) {
                cocina->platos_preparacion = realloc(cocina->platos_preparacion, (size_t)(cocina->cantidad_preparacion + 1) * sizeof(pedido_t));
            }else{
                cocina->platos_preparacion = malloc(sizeof(pedido_t));
            }
            
            if (cocina->platos_preparacion == NULL) {
                printf("Error al liberar memoria en platos_preparacion.\n");
                return;
            }

            i--;
        }
    }
}

/*
Pre condiciones:

Post condiciones: 

*/

void encargar_pedidos(mozo_t *mozo, cocina_t *cocina) {
    cocina->platos_preparacion = realloc(cocina->platos_preparacion, (size_t)(cocina->cantidad_preparacion + mozo->cantidad_pedidos) * sizeof(pedido_t));
    if (cocina->platos_preparacion == NULL) {
        printf("Error al reservar la memoria para los platos en preparación.\n");
        return;
    }
    int i = 0;
    while(i < mozo->cantidad_pedidos && cocina->cantidad_preparacion < MAX_BANDEJA){
        cocina->platos_preparacion[cocina->cantidad_preparacion] = mozo->pedidos[i];
        cocina->cantidad_preparacion++;
        i++;
    }
    printf("Encargaste %i pedidos!\n", mozo->cantidad_pedidos);
    mozo->cantidad_pedidos = 0;
}

/*
Pre condiciones:

Post condiciones: 

*/

void manejo_de_pedidos(mozo_t *mozo, cocina_t *cocina) {
    if(mozo->cantidad_pedidos > 0){
        encargar_pedidos(mozo, cocina);
    }
    if(cocina->cantidad_listos > 0 && mozo->cantidad_bandeja <= 6){
        pedidos_en_bandeja(mozo, cocina);
    }
}


/*
Pre condiciones:

Post condiciones: 

*/

void interaccion_cocina(mozo_t *mozo, cocina_t *cocina){
    if(!mozo->tiene_mopa ){
        bool misma_posicion_cocina = estoy_en_misma_pos(mozo->posicion,cocina->posicion);
        if(misma_posicion_cocina){
            manejo_de_pedidos(mozo, cocina);
        }
    }else{
        return;
    }
}

/*
Pre condiciones:

Post condiciones: 

*/

void interaccion_herramientas(mozo_t *mozo, objeto_t herramientas[], int *cantidad_herramientas, int *dinero){

    if(mozo->tiene_mopa){
        return;
    }else{
        interaccion_patines(mozo, herramientas, cantidad_herramientas);
        interaccion_monedas(mozo, herramientas, cantidad_herramientas, dinero);
    }
    
}


/*
Pre condiciones:

Post condiciones: 

*/

void interaccion_obstaculos(mozo_t *mozo, objeto_t obstaculos[], int *cantidad_obstaculos) {

    if(mozo->tiene_mopa){
        interaccion_charcos(*mozo, obstaculos, cantidad_obstaculos);
    }else{
        interaccion_cucaracha(*mozo, obstaculos, cantidad_obstaculos);
    }
}

/*
Pre condiciones:

Post condiciones: 

*/

void accion_mozo_patines(juego_t *juego, char accion) {
    bool movimiento_valido = true;
    coordenada_t posicion_actual_mozo = juego->mozo.posicion;
    
    while (movimiento_valido) {
        if (accion == ARRIBA) {
            posicion_actual_mozo.fil -= 1;
        } else if (accion == ABAJO) {
            posicion_actual_mozo.fil += 1;
        } else if (accion == DERECHA) {
            posicion_actual_mozo.col += 1;
        } else if (accion == IZQUIERDA) {
            posicion_actual_mozo.col -= 1;
        }
        
        movimiento_valido = es_accion_valida_mozo(posicion_actual_mozo, *juego);

        if(movimiento_valido){
            interaccion_obstaculos(&juego->mozo, juego->obstaculos, &juego->cantidad_obstaculos);
            interaccion_herramientas(&juego->mozo, juego->herramientas, &juego->cantidad_herramientas, &juego->dinero);
            juego->mozo.posicion = posicion_actual_mozo; 
        }
    }
    juego->movimientos++;
    juego->mozo.patines_puestos = false;
    juego->mozo.cantidad_patines--;
}

/*
Pre:
Post:
*/

void generar_pedido(pedido_t pedidos[], int *cantidad_pedidos, mesa_t mesa, int indice_mesa) {
    int cantidad_platos_actual = 0;
    int tiempo_de_preparacion_actual = 0;
    for(int i = 0; i < mesa.cantidad_comensales; i++) {
        int numero_pedido = generar_numero_aleatorio(4, 1);  
        if (numero_pedido == MILANESA_NAPOLITANA_ID) {
            pedidos[*cantidad_pedidos].platos[cantidad_platos_actual] = MILANESA_NAPOLITANA;
            if(TIEMPO_MILANESA_NAPOLITANA > tiempo_de_preparacion_actual)
                tiempo_de_preparacion_actual = TIEMPO_MILANESA_NAPOLITANA;
        } else if (numero_pedido == PARRILLA_ID) {
            pedidos[*cantidad_pedidos].platos[cantidad_platos_actual] = PARRILLA;
            if(TIEMPO_PARRILLA > tiempo_de_preparacion_actual)
                tiempo_de_preparacion_actual = TIEMPO_PARRILLA;
        } else if (numero_pedido == HAMBURGUESA_ID) {
            pedidos[*cantidad_pedidos].platos[cantidad_platos_actual] = HAMBURGUESA;
            if(TIEMPO_HAMBURGUESA > tiempo_de_preparacion_actual)
                tiempo_de_preparacion_actual = TIEMPO_HAMBURGUESA;
        } else {
            pedidos[*cantidad_pedidos].platos[cantidad_platos_actual] = RATATOUILLE;
            if(TIEMPO_RATATOUILLE > tiempo_de_preparacion_actual)
                tiempo_de_preparacion_actual = TIEMPO_RATATOUILLE;
        }

        cantidad_platos_actual++;
    }
    pedidos[*cantidad_pedidos].tiempo_preparacion = tiempo_de_preparacion_actual;
    pedidos[*cantidad_pedidos].id_mesa = indice_mesa;
    pedidos[*cantidad_pedidos].cantidad_platos = cantidad_platos_actual;
    (*cantidad_pedidos)++;
}

/*
Pre:
Post:
*/

int distancia_mozo_mesa(coordenada_t posicion_mozo, coordenada_t posicion_ocupada_mesa){
    return distancia_manhattan(posicion_mozo, posicion_ocupada_mesa);
}

/*
Pre:
Post:
*/

void tomar_pedido(coordenada_t posicion_mozo, juego_t *juego) {
    for (int i = 0; i < juego->cantidad_mesas; i++) {
        if (juego->mesas[i].cantidad_comensales != 0 && !juego->mesas[i].pedido_tomado) {
            for (int j = 0; j < juego->mesas[i].cantidad_comensales; j++) {
                int distancia_mozo = distancia_mozo_mesa(posicion_mozo, juego->mesas[i].posicion[j]);

                if (distancia_mozo <= 1 && juego->mozo.cantidad_pedidos < MAX_PEDIDOS ){
                    juego->mesas[i].pedido_tomado = true;
                    generar_pedido(juego->mozo.pedidos, &juego->mozo.cantidad_pedidos, juego->mesas[i], i);
                    printf("Pedido tomado de la mesa %d!\n", i + 1);
                }
            }
        }
    }
}



/*
Pre condiciones:

Post condiciones: 

*/

void activar_patines(int cantidad_patines, juego_t *juego, char accion){
    if(cantidad_patines > 0){
        if(!juego->mozo.patines_puestos){
            juego->mozo.patines_puestos = true;
            printf("Patines activados! \n");
            
        }
    }else if(cantidad_patines <= 0){
        printf("No tienes patines disponibles! \n");
        
    }
}

/*
Pre condiciones:

Post condiciones: 

*/

void interaccion_pedidos(coordenada_t posicion_mozo, juego_t *juego){
    if(!juego->mozo.tiene_mopa){
        tomar_pedido(posicion_mozo, juego);
    }else{
        printf("No es posible tomar pedidos con la mopa agarrada. \n");
        
    }
}


/*
Pre condiciones: La accion debe ser valida la posicion del mozo debe estar inicializada.

Post condiciones: Genera la nueva posicion del mozo en base a que accion se ingreso.

*/

void generar_nueva_accion_mozo(juego_t *juego, char accion){

    if(juego->mozo.patines_puestos){
        accion_mozo_patines(juego, accion); 
        return;
    }

    coordenada_t posicion_actual_mozo_mod;
    posicion_actual_mozo_mod.fil = juego->mozo.posicion.fil;
    posicion_actual_mozo_mod.col = juego->mozo.posicion.col;

    if(accion == ARRIBA){
        posicion_actual_mozo_mod.fil -= 1;
    }
    if ( accion == ABAJO){
        posicion_actual_mozo_mod.fil += 1;
    }
    if(accion == DERECHA){
        posicion_actual_mozo_mod.col += 1;
    }
    if (accion == IZQUIERDA){
        posicion_actual_mozo_mod.col -= 1;
    }

    bool accion_mozo_valida = es_accion_valida_mozo(posicion_actual_mozo_mod, *juego);

    if(accion_mozo_valida){
        actualizar_paciencia(juego->cantidad_mesas, juego->mesas, juego);
        juego->mozo.posicion.fil = posicion_actual_mozo_mod.fil;
        juego->mozo.posicion.col = posicion_actual_mozo_mod.col;

        interaccion_obstaculos(&juego->mozo, juego->obstaculos, &juego->cantidad_obstaculos);
        interaccion_herramientas(&juego->mozo, juego->herramientas, &juego->cantidad_herramientas, &juego->dinero);
        interaccion_cocina(&juego->mozo, &juego->cocina);
        entregar_pedidos(&juego->mozo, juego->mesas, juego->cantidad_mesas, juego);

        juego->movimientos++;
    }
}

/*
Pre: -
Post: 
*/


bool hay_asientos_libres(int cantidad_mesas, mesa_t *mesa, int *indice_mesa_con_lugar, int comensales_a_ingresar){

    bool encontre_lugar = false;
    int i = 0;

    if(comensales_a_ingresar == 1){
        while(!encontre_lugar && i < cantidad_mesas){
            if(mesa[i].cantidad_lugares == 1 && mesa[i].cantidad_comensales == 0){
                encontre_lugar = true;
                *indice_mesa_con_lugar = i;
            }
            i++;
        }
        i = 0;
        while(!encontre_lugar && i < cantidad_mesas){
            if(mesa[i].cantidad_lugares == 4 && mesa[i].cantidad_comensales == 0){
                encontre_lugar = true;
                *indice_mesa_con_lugar = i;
            }
            i++;
        }
    }else {
        i = 0;
        while(!encontre_lugar && i < cantidad_mesas){
            if(mesa[i].cantidad_comensales == 0 && mesa[i].cantidad_lugares >= comensales_a_ingresar){
                encontre_lugar = true;
                *indice_mesa_con_lugar = i;
            }
            i++;
        }
    }

    return encontre_lugar;
}


/*
Pre:
Post:
*/

void asignar_comensales(mesa_t *mesa, int cantidad_mesas, int comensales_a_ingresar){

    int indice_mesa_con_lugar;
    bool encontre_lugar = hay_asientos_libres(cantidad_mesas, mesa, &indice_mesa_con_lugar, comensales_a_ingresar);

    if(encontre_lugar){
        int paciencia_aleatoria = generar_numero_aleatorio(RANGO_PACIENCIA_MAXIMA, RANGO_PACIENCIA_MINIMA);
        mesa[indice_mesa_con_lugar].cantidad_comensales = comensales_a_ingresar;
        mesa[indice_mesa_con_lugar].paciencia = paciencia_aleatoria;
    }
}

/*
Pre:
Post:
*/

void aparecer_cucarachas(juego_t *juego){
    coordenada_t posicion_aleatoria;
    bool posicion_invalida = true;

    while(posicion_invalida){
        posicion_aleatoria = generar_posicion_aleatoria();
        bool encontre_posicion = hay_posicion_libre(*juego, posicion_aleatoria);
        if(encontre_posicion){
            juego->obstaculos[juego->cantidad_obstaculos].posicion.fil = posicion_aleatoria.fil;
            juego->obstaculos[juego->cantidad_obstaculos].posicion.col = posicion_aleatoria.col;
            juego->obstaculos[juego->cantidad_obstaculos].tipo = CUCARACHA;
            juego->cantidad_obstaculos++;
            posicion_invalida = false;
        }
    }

}


/*
Pre:
Post:
*/

void llegada_comensales(juego_t *juego){

    int cantidad_comensales = generar_numero_aleatorio(MAX_COMENSALES,MIN_COMENSALES);

    asignar_comensales(juego->mesas,juego->cantidad_mesas, cantidad_comensales);
}


/*
Pre:
Post:
*/

void actualizacion_del_juego(juego_t *juego){
    if(juego->movimientos % 15 == 0 && juego->movimientos > 0){
        llegada_comensales(juego);
    }
    if(juego->movimientos % 25 == 0 && juego->movimientos > 0){
        aparecer_cucarachas(juego);
    }
    if(juego->cocina.cantidad_preparacion > 0){
        actualizar_pedidos(&juego->cocina);
    }
}


/*Funciones del .h*/


void inicializar_juego(juego_t *juego){

    juego->cantidad_mesas = CANTIDAD_MESAS;
    juego->cantidad_herramientas = CANTIDAD_HERRAMIENTAS;
    juego->cantidad_obstaculos = CANTIDAD_OBSTACULOS;
    juego->dinero = 0;
    juego->movimientos = 0;

    bool tablero[MAX_FILAS][MAX_COLUMNAS];
    inicializar_tablero(tablero);


    inicializar_mesas(tablero, juego);



    inicializar_herramientas(tablero, juego);


    inicializar_obstaculos(tablero, juego);

    
    inicializar_mozo(tablero, &juego->mozo);


    inicializar_cocina(tablero, &juego->cocina);

}



void mostrar_juego(juego_t juego){

    imprimir_juego(juego);
}


void realizar_jugada(juego_t *juego, char accion){

    if(accion == MOPA){
        interaccion_mopa(juego->mozo.posicion, juego);
    }else if(accion == PATINES){
        activar_patines(juego->mozo.cantidad_patines, juego, accion);
    }else if(accion == TOMAR_PEDIDO){
        interaccion_pedidos(juego->mozo.posicion, juego);
    }
    else{
        generar_nueva_accion_mozo(juego, accion);
    }

    actualizacion_del_juego(juego);
}

int estado_juego(juego_t juego){
    if(juego.movimientos == MAX_MOVIMIENTOS){
        if(juego.dinero >= OBJETIVO_DINERO){
            return GANO;
        }else{
            return PERDIO;
        }
    }
    return CONTINUAR_JUGANDO;
}

void destruir_juego(juego_t *juego){
    free(juego->cocina.platos_preparacion);
    free(juego->cocina.platos_listos);
}